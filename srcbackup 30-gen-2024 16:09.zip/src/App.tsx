import React from 'react';
import SidePanel from './components/SidePanel';
import Breadcrumb from './components/Breadcrumb';
import Dashboard from './components/DashboardSection';
import DataTable from './components/Datatable';
import './app.scss';

const App: React.FC = () => {
  const data = [
    { id: 1, username: 'user1', dateTime: '2024-01-30 12:00', amount: 100, status: 'completed' },
    // Aggiungi altri dati di esempio
  ];

  return (
    <div className="app">
      <SidePanel />
      <div className="main-content">
        <Breadcrumb path="Control Panel > Dashboard" />
        <Dashboard />
        <DataTable data={data} />
      </div>
    </div>
  );
};

export default App;
