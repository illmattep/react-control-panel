import React, { useState } from 'react';
import './Datatable.scss';

interface DataTableProps {
  data: Array<{
    id: number;
    username: string;
    dateTime: string;
    amount: number;
    status: string;
  }>;
}

const DataTable: React.FC<DataTableProps> = ({ data }) => {
  const [sortBy, setSortBy] = useState('');

  const handleSort = (key: string) => {
    // Implementa la logica di ordinamento
    setSortBy(key);
  };

  return (
    <table className="data-table">
      <thead>
        <tr>
          <th onClick={() => handleSort('id')}>ID</th>
          <th onClick={() => handleSort('username')}>Username</th>
          <th onClick={() => handleSort('dateTime')}>Date & Time</th>
          <th onClick={() => handleSort('amount')}>Amount</th>
          <th onClick={() => handleSort('status')}>Status</th>
        </tr>
      </thead>
      <tbody>
        {data.map((item) => (
          <tr key={item.id}>
            <td>{item.id}</td>
            <td>{item.username}</td>
            <td>{item.dateTime}</td>
            <td>{item.amount}</td>
            <td>{item.status}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default DataTable;
